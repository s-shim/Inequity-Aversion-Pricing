inequityAversionPricingExperiments.py is a python code to run GURBI on the data.
In Lines 8 and 9, the user may set up data ID and the number of replicates. 
For data ID, please refer to Table 3 of the article, "Extended Graph Formulation for the Inequity Aversion Pricing Problem on Social Networks". 
You can download the article at https://www.researchgate.net/publication/346300880_Extended_Graph_Formulation_for_the_Inequity_Aversion_Pricing_Problem_on_Social_Networks?showFulltext=1&linkId=5fbdab7b92851c933f57b20e
