from gurobipy import *
import pandas as pd
import networkx as nx

priceOptions = ['discontinuity', 30, 60, 90, 120, 150, 180, 210, 240, 270, 300,330,360,390,420,450,480,510,540,570,600]
tolerance = 0

lines = pd.read_csv('lines/lines_9.csv')
nodes = pd.read_csv('nodes/nodes_9_0.csv')

G = nx.Graph()
for v in nodes['Node']:
    [value_v] = nodes.loc[nodes['Node'] == v,'Value']
    G.add_node(v,value=value_v)
    #print(v,G.node[v]['value'])
    
for l in lines['Line']:
    [Source] = lines.loc[lines['Line'] == l,'Source']
    [Target] = lines.loc[lines['Line'] == l,'Target']
    G.add_edge(Source,Target)

# ILP Model
model = Model('Inequity Aversion Pricing')

# Employ variables
## Employ X variables indicating option assignment
x_vars = []
x_names = []
for v in G.nodes():
    for option in priceOptions:
        x_vars += [(v,option)]
        x_names += ['X[%s,%s]'%(v,option)]
X = model.addVars(x_vars, vtype = GRB.BINARY, name = x_names)

## Employ Z variables a pair of option assignments on two end nodes of an edge
z_vars = []
z_names = []
for (u,v) in G.edges():
    for ju in priceOptions:
        for jv in priceOptions:
            z_vars += [((u,ju),(v,jv))]
            z_names += ['Z[(%s,%s),(%s,%s)]'%(u,ju,v,jv)]
Z = model.addVars(z_vars, vtype = GRB.BINARY, name = z_names)

# Add constraints
## Add partition equations
for v in G.nodes():
    LHS = []
    for option in priceOptions:
        LHS += [(1,X[v,option])]
    model.addConstr(LinExpr(LHS)==1, name='Eq.partition(%s)'%v)

## Bundle equations
for (u,v) in G.edges():
    for ju in priceOptions:
        LHS =  [(-1,X[u,ju])]
        for jv in priceOptions:
            LHS += [(1,Z[(u,ju),(v,jv)])]
        model.addConstr(LinExpr(LHS)==0, name='Eq.bundle(%s,%s)On(%s,%s)'%(u,ju,u,v))            
    for jv in priceOptions:
        LHS =  [(-1,X[v,jv])]
        for ju in priceOptions:
            LHS += [(1,Z[(u,ju),(v,jv)])]
        model.addConstr(LinExpr(LHS)==0, name='Eq.bundle(%s,%s)On(%s,%s)'%(v,jv,u,v))
        
## Boundary constraints
### tolerance
for (u,v) in G.edges():
    for ju in priceOptions:
        for jv in priceOptions:
            if ju != 'discontinuity':
                if jv != 'discontinuity':
                    if abs(ju - jv) > tolerance:
                        LHS = [(1,Z[(u,ju),(v,jv)])]
                        model.addConstr(LinExpr(LHS)==0, name='Eq.tolerance(%s,%s)(%s,%s)'%(u,ju,v,jv))
    
    
# Objective Function
objTerms = []
for v in G.nodes():
    for option in priceOptions:
        if option != 'discontinuity':
            if G.nodes[v]['value'] >= option:
                objTerms += [(option,X[v,option])]
                

model.setObjective(LinExpr(objTerms), GRB.MAXIMIZE)


# update and solve the model
model.update()
model.optimize()


# read the optimal solution
variableName = []
variableValue = []
for v in model.getVars():
    if v.x > 0:
        variableName += [v.varname]
        variableValue += [v.x]

optSolution = pd.DataFrame(list(zip(variableName, variableValue)),columns =['varName', 'varVal'])
optSolution.to_csv(r'optSolution.csv', index = False)#Check
